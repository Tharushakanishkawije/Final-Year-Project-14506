import sys
import subprocess
import firebase_admin
from firebase_admin import db, credentials

def upload_status_to_firebase():

    # Initialize Firebase
    cred = credentials.Certificate("/home/rasp/Desktop/Monitoring_System/credentials.json")
    firebase_admin.initialize_app(cred, {"databaseURL": "https://project-57c3f-default-rtdb.firebaseio.com/"})
    
    # Create reference to root node
    ref = db.reference("/")
    
    # turn off the firewall
    output = subprocess.check_output('/home/rasp/Desktop/Monitoring_System/firewall/Toggle_Off/toggleFWoff.sh')
    output = output.decode('utf-8').strip()

    # Upload data
    ref.update({'firewall_status': output})

def main():
    upload_status_to_firebase()

if __name__ == "__main__":
    main()
