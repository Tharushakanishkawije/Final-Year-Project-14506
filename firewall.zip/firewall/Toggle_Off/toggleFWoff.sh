#!/bin/bash

# turn off the firewall
sudo systemctl stop ufw
echo "off"