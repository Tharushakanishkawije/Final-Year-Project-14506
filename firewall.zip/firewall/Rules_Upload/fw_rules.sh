#!/bin/bash

# extract rules from the xml file
python3 /home/rasp/Desktop/Monitoring_System/firewall/Rules_Upload/extractRules.py

# virtual environment activation
echo "Starting data extraction"
cd /home/rasp/Desktop/Monitoring_System/
python3 -m venv myenv
source /home/rasp/Desktop/Monitoring_System/myenv/bin/activate

# firebase_admin manager
echo "Establishing DB connecton"
python3 /home/rasp/Desktop/Monitoring_System/firebase_admin_manager.py

# extract alert data from python file
echo "Uploading data"
python3 /home/rasp/Desktop/Monitoring_System/firewall/Rules_Upload/feed_data.py

echo "Rule data upload done."
