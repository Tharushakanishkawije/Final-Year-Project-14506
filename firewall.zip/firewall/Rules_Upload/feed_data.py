import sys
import xml.etree.ElementTree as ET
import firebase_admin
from firebase_admin import db, credentials

def upload_rules_to_firebase(xml_file):
    # Load the XML file
    tree = ET.parse(xml_file)
    root = tree.getroot()

    # Initialize Firebase
    cred = credentials.Certificate("/home/rasp/Desktop/Monitoring_System/credentials.json")
    firebase_admin.initialize_app(cred, {"databaseURL": "https://project-57c3f-default-rtdb.firebaseio.com/"})
    
    # Delete existing values under "/idps" node
    db.reference("/firewall").delete()

    # Counter for rule entries
    counter = 1

    # Iterate through each rule in the XML
    for rule in root.findall('.//rule'):
        # Extract rule data
        action = rule.find('action').text
        port = rule.find('port').text
        protocol = rule.find('protocol').text

        # Define the data object
        data = {
            "action": action,
            "port": port,
            "protocol": protocol
        }

        # Create reference to root node
        ref = db.reference(f"/firewall/rule{counter}")

        # Upload data
        ref.update(data)

        # Update counter
        counter += 1

def main():
    upload_rules_to_firebase('/home/rasp/Desktop/Monitoring_System/firewall/Rules_Upload/ufw_rules.xml')

if __name__ == "__main__":
    main()
