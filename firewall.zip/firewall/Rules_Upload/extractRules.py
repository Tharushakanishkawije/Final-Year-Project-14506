import subprocess
import re
import xml.etree.ElementTree as ET

def get_ufw_rules():
    try:
        # Run ufw status command to get the rules
        ufw_status = subprocess.run(['sudo', 'ufw', 'status', 'numbered'], capture_output=True, text=True)
        output_lines = ufw_status.stdout.strip().split('\n')
        
        # Initialize list to store rule details
        rule_details = []
        
        # Regular expression pattern to match rule lines
        rule_pattern = r"\[\s*\d+\]\s+(\S+)\s+(\S+)\s+\S+\s+(\S+)\s*(?:#.*)?"
        
        # Iterate through each line and match rule pattern
        for line in output_lines:
            match = re.match(rule_pattern, line)
            if match:
                port_proto, action, direction = match.groups()
                port, protocol = port_proto.split('/')
                if action != '(v6)':  # Exclude entries with action 'v6'
                    rule_details.append({'action': action, 'port': port, 'protocol': protocol})
            else:
                print("Skipping non-rule line:", line)
        
        return rule_details
    except Exception as e:
        print("Error:", e)
        return []

def export_to_xml(rule_details):
    # Create root element for XML
    root = ET.Element("ufw_rules")
    
    # Iterate through each rule and create XML elements
    for rule in rule_details:
        rule_element = ET.SubElement(root, "rule")
        action_element = ET.SubElement(rule_element, "action")
        action_element.text = rule['action']
        port_element = ET.SubElement(rule_element, "port")
        port_element.text = rule['port']
        protocol_element = ET.SubElement(rule_element, "protocol")
        protocol_element.text = rule['protocol']
    
    # Create XML tree
    tree = ET.ElementTree(root)
    
    # Write XML tree to file
    tree.write("ufw_rules.xml")

def main():
    # Get ufw rules
    rule_details = get_ufw_rules()
    
    if rule_details:
        # Export rules to XML file
        export_to_xml(rule_details)
        
        print("UFW rules exported to ufw_rules.xml")
    else:
        print("Failed to retrieve UFW rules")

if __name__ == "__main__":
    main()
