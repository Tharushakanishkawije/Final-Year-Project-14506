#!/bin/bash

# virtual environment activation
echo "Starting data extraction"
cd /home/rasp/Desktop/Monitoring_System/
python3 -m venv myenv
source /home/rasp/Desktop/Monitoring_System/myenv/bin/activate

# firebase_admin manager
echo "Establishing DB connecton"
python3 /home/rasp/Desktop/Monitoring_System/firebase_admin_manager.py

# extract upload data using python file
echo "Uploading data"
python3 /home/rasp/Desktop/Monitoring_System/firewall/Toggle_On/FW_on_data_upload.py

echo "Status data upload done."