#!/bin/bash

# turn on the firewall
sudo systemctl start ufw
echo "on"