import sys
import xml.etree.ElementTree as ET
import firebase_admin
from firebase_admin import db, credentials

def hostsDataFeed():
    # Load the XML file
    tree = ET.parse('/home/rasp/Desktop/Monitoring_System/hostDiscovery/network_scan.xml')
    root = tree.getroot()

    # delete existing values
    db.reference("/hosts").delete()

    # counter
    counter = 1

    # Iterate through each host in the original XML
    for host in root.findall('.//host'):
        # Extract IP address, and osmatch name
        ip_address = host.find('.//address[@addrtype="ipv4"]').attrib['addr']
        try:
            osmatch_name = host.find('.//os/osmatch').attrib['name']
        except AttributeError:
            osmatch_name = "unidentified"

        # define the data object
        data = {"id": counter, "ip": ip_address, "os": osmatch_name}

        # creating reference to root node
        ref = db.reference(f"/hosts/host{counter}")

        # upload data
        ref.update(data)

        # couter update
        counter=counter+1

def main():
    # authenticate to firebase
    cred = credentials.Certificate("/home/rasp/Desktop/Monitoring_System/credentials.json")
    firebase_admin.initialize_app(cred, {"databaseURL": "https://project-57c3f-default-rtdb.firebaseio.com/"})
    
    hostsDataFeed()

if __name__ == "__main__":
    main()
