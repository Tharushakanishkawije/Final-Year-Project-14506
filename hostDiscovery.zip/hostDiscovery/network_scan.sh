#!/bin/bash

# get local IP address
echo "Identifying network IP range"
local_ip=$(hostname -I | awk '{print $1}')

# run nmap to identify active hosts and export to xml
echo "Scanning for devices"
nmap_result=$(sudo nmap -O $local_ip/24 -oX /home/rasp/Desktop/Monitoring_System/hostDiscovery/network_scan.xml)

# virtual environment activation
echo "Starting data extraction"
cd /home/rasp/Desktop/Monitoring_System/
python3 -m venv myenv
source /home/rasp/Desktop/Monitoring_System/myenv/bin/activate

# firebase_admin manager
echo "Establishing DB connecton"
python3 /home/rasp/Desktop/Monitoring_System/firebase_admin_manager.py

# extract host data from python file
echo "Uploading data"
python3 /home/rasp/Desktop/Monitoring_System/hostDiscovery/feed_data.py

echo "Network scan done"
