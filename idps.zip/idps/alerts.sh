#!/bin/bash

# virtual environment activation
echo "Starting data extraction"
cd /home/rasp/Desktop/Monitoring_System/
python3 -m venv myenv
source /home/rasp/Desktop/Monitoring_System/myenv/bin/activate

# firebase_admin manager
echo "Establishing DB connecton"
python3 /home/rasp/Desktop/Monitoring_System/firebase_admin_manager.py

# extract alert data from python file
python3 /home/rasp/Desktop/Monitoring_System/idps/extractAlerts.py

# uploading data
echo "Uploading data"
python3 /home/rasp/Desktop/Monitoring_System/idps/feed_data.py

echo "Alert data upload done."
