#!/bin/bash

# Path to Suricata alerts file
ALERTS_FILE="/var/log/suricata/fast.log"

# Clear Suricata alerts by overwriting the file with an empty string
echo -n "" > "$ALERTS_FILE"
echo "Suricata alerts cleared successfully."

# remove the old logs file
rm /home/rasp/Desktop/Monitoring_System/idps/logs.xml

# run the alerts script
/home/rasp/Desktop/Monitoring_System/idps/alerts.sh

