import sys
import subprocess
import firebase_admin
from firebase_admin import db, credentials

def upload_status_to_firebase():

    # Initialize Firebase
    cred = credentials.Certificate("/home/rasp/Desktop/Monitoring_System/credentials.json")
    firebase_admin.initialize_app(cred, {"databaseURL": "https://project-57c3f-default-rtdb.firebaseio.com/"})
    

    # Create reference to root node
    ref = db.reference("/")
    
    # turn off the idps
    output = subprocess.check_output('/home/rasp/Desktop/Monitoring_System/idps/Toggle_Off/toggleIdpsoff.sh')
    output = output.decode('utf-8').strip()
    print(output)

    # Upload data
    ref.update({'idps_status': output})

def main():
    upload_status_to_firebase()

if __name__ == "__main__":
    main()
