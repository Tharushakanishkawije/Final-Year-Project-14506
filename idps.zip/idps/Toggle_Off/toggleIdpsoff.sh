#!/bin/bash

# turn off idps
sudo systemctl stop suricata
echo "off"