import xml.etree.ElementTree as ET
import re

# Open the fast.log file for reading
with open('/var/log/suricata/fast.log', 'r') as file:
    # Create the root element of the XML tree
    root = ET.Element("logs")

    # Iterate through each line in the file
    for line in file:
        # Split the line by spaces
        parts = line.split()
        
        # Extract relevant information from the line
        classification_start_index = line.find('[Classification:') + 16
        classification_end_index = line.find(']', classification_start_index)
        classification = line[classification_start_index:classification_end_index].strip()

        priority_start_index = line.find('[Priority:') + 10
        priority_end_index = line.find(']', priority_start_index)
        priority = line[priority_start_index:priority_end_index].strip()

        # Extract protocol using regular expression
        protocol_match = re.search(r'{(.*?)\}', line)
        protocol = protocol_match.group(1) if protocol_match else None

        source_ip = parts[-3].split(':')[0]  # Extracting source IP from the 3rd last part
        destination_ip = parts[-1].split('->')[-1].split(':')[0]  # Extracting destination IP from the last part
        
        # Create a dictionary to store the extracted information
        log_data = {
            "classification": classification,
            "priority": priority,
            "protocol": protocol,
            "source_ip": source_ip,
            "destination_ip": destination_ip
        }
        
        # Create an XML element for the log data
        log_element = ET.SubElement(root, "log")
        for key, value in log_data.items():
            element = ET.SubElement(log_element, key)
            element.text = value

# Create an XML tree and write it to a file
tree = ET.ElementTree(root)
tree.write("/home/rasp/Desktop/Monitoring_System/idps/logs.xml")