#!/bin/bash

# turn on idps
sudo systemctl start suricata
echo "on"