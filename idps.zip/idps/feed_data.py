import os.path
import xml.etree.ElementTree as ET
import firebase_admin
from firebase_admin import db, credentials

def upload_logs_to_firebase():
    # Path to the XML file
    xml_file_path = '/home/rasp/Desktop/Monitoring_System/idps/logs.xml'
    
    # Check if the XML file exists
    if os.path.exists(xml_file_path):
        # Load the XML file
        try:
            tree = ET.parse(xml_file_path)
            root = tree.getroot()
        
            # Initialize Firebase
            cred = credentials.Certificate("/home/rasp/Desktop/Monitoring_System/credentials.json")
            firebase_admin.initialize_app(cred, {"databaseURL": "https://project-57c3f-default-rtdb.firebaseio.com/"})
            
            # Delete existing values under "/idps" node
            db.reference("/idps").delete()

            # Counter for log entries
            counter = 1
                
            # Iterate through each log entry in the XML
            for log in root.findall('.//log'):
                # Extract log data
                classification = log.find('classification').text
                priority = log.find('priority').text
                protocol = log.find('protocol').text
                source_ip = log.find('source_ip').text
                destination_ip = log.find('destination_ip').text

                # Define the data object
                data = {
                    "classification": classification,
                    "priority": priority,
                    "protocol": protocol,
                    "source_ip": source_ip,
                    "destination_ip": destination_ip
                }

                # Create reference to root node
                ref = db.reference(f"/idps/log{counter}")

                # Upload data
                ref.update(data)

                # Update counter
                counter += 1
        
        except ET.ParseError as e:
            print("Error parsing XML file:", e)
        
        except Exception as e:
            print("Error:", e)
    else:
        # If the XML file does not exist, delete all data in the "idps" node
        try:
            # Initialize Firebase
            cred = credentials.Certificate("/home/rasp/Desktop/Monitoring_System/credentials.json")
            firebase_admin.initialize_app(cred, {"databaseURL": "https://project-57c3f-default-rtdb.firebaseio.com/"})
            
            # Delete all data in the "idps" node
            db.reference("/idps").delete()
            print("All data in 'idps' node deleted.")
        
        except Exception as e:
            print("Error:", e)

def main():
    upload_logs_to_firebase()

if __name__ == "__main__":
    main()
